package com.example.myapplication5.models;

public class ContactChange {

    String givenName;
    String familyName;
    int phoneNumber;
}
